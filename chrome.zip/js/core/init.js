var Extension = new _Extension();
Extension.currentVersion = 1;
Extension.checkVersion();
$(document).ready(function(){
    Extension.init();
});




